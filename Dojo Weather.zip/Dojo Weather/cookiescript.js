console.log("page loaded")


function popup(){
    alert("Weather Reports loading")
}

var accept = document.querySelector("#cookies")
function acceptcookie(){
    accept.remove()
}

